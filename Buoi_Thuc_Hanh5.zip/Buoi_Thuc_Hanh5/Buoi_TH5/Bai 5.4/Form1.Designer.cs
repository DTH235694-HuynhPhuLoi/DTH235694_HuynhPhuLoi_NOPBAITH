﻿namespace Bai_5._4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoChuNhat = new System.Windows.Forms.RadioButton();
            this.rdoTamGiac = new System.Windows.Forms.RadioButton();
            this.rdoTron = new System.Windows.Forms.RadioButton();
            this.rdoVuong = new System.Windows.Forms.RadioButton();
            this.groupHinhVuong = new System.Windows.Forms.GroupBox();
            this.txtNhapCanhVuong = new System.Windows.Forms.TextBox();
            this.txtCVHinhVuong = new System.Windows.Forms.TextBox();
            this.txtDTHinhVuong = new System.Windows.Forms.TextBox();
            this.btnThucHien = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.groupHinhTamGiac = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNhapCanhC = new System.Windows.Forms.TextBox();
            this.txtNhapCanhB = new System.Windows.Forms.TextBox();
            this.txtNhapCanhA = new System.Windows.Forms.TextBox();
            this.txtCVHinhTamGiac = new System.Windows.Forms.TextBox();
            this.txtDTHinhTamGiac = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupHinhChuNhat = new System.Windows.Forms.GroupBox();
            this.txtNhapChieuRong = new System.Windows.Forms.TextBox();
            this.txtCVHinhChuNhat = new System.Windows.Forms.TextBox();
            this.txtDTHinhChuNhat = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtNhapChieuDai = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.groupHinhTron = new System.Windows.Forms.GroupBox();
            this.txtNhapBanKinh = new System.Windows.Forms.TextBox();
            this.txtCVHinhTron = new System.Windows.Forms.TextBox();
            this.txtDTHinhTron = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblLoaiTamGiac = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupHinhVuong.SuspendLayout();
            this.groupHinhTamGiac.SuspendLayout();
            this.groupHinhChuNhat.SuspendLayout();
            this.groupHinhTron.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(440, 115);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(287, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hình Tam Giác - Hình Chữ Nhật ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(477, 88);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(216, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Hình Tròn - Hình Vuông ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(416, 36);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(340, 35);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tìm Chu Vi và Diện Tích ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 136);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 23);
            this.label4.TabIndex = 3;
            this.label4.Text = "Diện tích: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 95);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 23);
            this.label5.TabIndex = 4;
            this.label5.Text = "Chu vi:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 51);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 23);
            this.label6.TabIndex = 5;
            this.label6.Text = "Nhập cạnh a:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoChuNhat);
            this.groupBox1.Controls.Add(this.rdoTamGiac);
            this.groupBox1.Controls.Add(this.rdoTron);
            this.groupBox1.Controls.Add(this.rdoVuong);
            this.groupBox1.Location = new System.Drawing.Point(401, 157);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(364, 168);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chọn";
            // 
            // rdoChuNhat
            // 
            this.rdoChuNhat.AutoSize = true;
            this.rdoChuNhat.Location = new System.Drawing.Point(185, 114);
            this.rdoChuNhat.Margin = new System.Windows.Forms.Padding(4);
            this.rdoChuNhat.Name = "rdoChuNhat";
            this.rdoChuNhat.Size = new System.Drawing.Size(155, 27);
            this.rdoChuNhat.TabIndex = 6;
            this.rdoChuNhat.Text = "Hình chữ nhật ";
            this.rdoChuNhat.UseVisualStyleBackColor = true;
            // 
            // rdoTamGiac
            // 
            this.rdoTamGiac.AutoSize = true;
            this.rdoTamGiac.Location = new System.Drawing.Point(187, 30);
            this.rdoTamGiac.Margin = new System.Windows.Forms.Padding(4);
            this.rdoTamGiac.Name = "rdoTamGiac";
            this.rdoTamGiac.Size = new System.Drawing.Size(153, 27);
            this.rdoTamGiac.TabIndex = 5;
            this.rdoTamGiac.Text = "Hình tam giác ";
            this.rdoTamGiac.UseVisualStyleBackColor = true;
            // 
            // rdoTron
            // 
            this.rdoTron.AutoSize = true;
            this.rdoTron.Location = new System.Drawing.Point(40, 30);
            this.rdoTron.Margin = new System.Windows.Forms.Padding(4);
            this.rdoTron.Name = "rdoTron";
            this.rdoTron.Size = new System.Drawing.Size(112, 27);
            this.rdoTron.TabIndex = 3;
            this.rdoTron.Text = "Hình tròn";
            this.rdoTron.UseVisualStyleBackColor = true;
            // 
            // rdoVuong
            // 
            this.rdoVuong.AutoSize = true;
            this.rdoVuong.Location = new System.Drawing.Point(40, 114);
            this.rdoVuong.Margin = new System.Windows.Forms.Padding(4);
            this.rdoVuong.Name = "rdoVuong";
            this.rdoVuong.Size = new System.Drawing.Size(127, 27);
            this.rdoVuong.TabIndex = 4;
            this.rdoVuong.Text = "Hình vuông";
            this.rdoVuong.UseVisualStyleBackColor = true;
            this.rdoVuong.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // groupHinhVuong
            // 
            this.groupHinhVuong.Controls.Add(this.txtNhapCanhVuong);
            this.groupHinhVuong.Controls.Add(this.txtCVHinhVuong);
            this.groupHinhVuong.Controls.Add(this.txtDTHinhVuong);
            this.groupHinhVuong.Controls.Add(this.label6);
            this.groupHinhVuong.Controls.Add(this.label5);
            this.groupHinhVuong.Controls.Add(this.label4);
            this.groupHinhVuong.Location = new System.Drawing.Point(13, 400);
            this.groupHinhVuong.Margin = new System.Windows.Forms.Padding(4);
            this.groupHinhVuong.Name = "groupHinhVuong";
            this.groupHinhVuong.Padding = new System.Windows.Forms.Padding(4);
            this.groupHinhVuong.Size = new System.Drawing.Size(199, 173);
            this.groupHinhVuong.TabIndex = 0;
            this.groupHinhVuong.TabStop = false;
            this.groupHinhVuong.Text = "Hình vuông";
            // 
            // txtNhapCanhVuong
            // 
            this.txtNhapCanhVuong.Location = new System.Drawing.Point(136, 44);
            this.txtNhapCanhVuong.Margin = new System.Windows.Forms.Padding(4);
            this.txtNhapCanhVuong.Name = "txtNhapCanhVuong";
            this.txtNhapCanhVuong.Size = new System.Drawing.Size(52, 30);
            this.txtNhapCanhVuong.TabIndex = 9;
            // 
            // txtCVHinhVuong
            // 
            this.txtCVHinhVuong.Location = new System.Drawing.Point(136, 88);
            this.txtCVHinhVuong.Margin = new System.Windows.Forms.Padding(4);
            this.txtCVHinhVuong.Name = "txtCVHinhVuong";
            this.txtCVHinhVuong.Size = new System.Drawing.Size(52, 30);
            this.txtCVHinhVuong.TabIndex = 7;
            // 
            // txtDTHinhVuong
            // 
            this.txtDTHinhVuong.Location = new System.Drawing.Point(136, 126);
            this.txtDTHinhVuong.Margin = new System.Windows.Forms.Padding(4);
            this.txtDTHinhVuong.Name = "txtDTHinhVuong";
            this.txtDTHinhVuong.Size = new System.Drawing.Size(50, 30);
            this.txtDTHinhVuong.TabIndex = 8;
            // 
            // btnThucHien
            // 
            this.btnThucHien.Location = new System.Drawing.Point(351, 346);
            this.btnThucHien.Margin = new System.Windows.Forms.Padding(4);
            this.btnThucHien.Name = "btnThucHien";
            this.btnThucHien.Size = new System.Drawing.Size(112, 33);
            this.btnThucHien.TabIndex = 0;
            this.btnThucHien.Text = "Thức Hiện";
            this.btnThucHien.UseVisualStyleBackColor = true;
            this.btnThucHien.Click += new System.EventHandler(this.btnThucHien_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(531, 346);
            this.btnReset.Margin = new System.Windows.Forms.Padding(4);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(112, 33);
            this.btnReset.TabIndex = 1;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(703, 346);
            this.btnThoat.Margin = new System.Windows.Forms.Padding(4);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(112, 33);
            this.btnThoat.TabIndex = 2;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // groupHinhTamGiac
            // 
            this.groupHinhTamGiac.Controls.Add(this.lblLoaiTamGiac);
            this.groupHinhTamGiac.Controls.Add(this.txtCVHinhTamGiac);
            this.groupHinhTamGiac.Controls.Add(this.txtDTHinhTamGiac);
            this.groupHinhTamGiac.Controls.Add(this.label10);
            this.groupHinhTamGiac.Controls.Add(this.label11);
            this.groupHinhTamGiac.Controls.Add(this.txtNhapCanhC);
            this.groupHinhTamGiac.Controls.Add(this.label9);
            this.groupHinhTamGiac.Controls.Add(this.txtNhapCanhB);
            this.groupHinhTamGiac.Controls.Add(this.label8);
            this.groupHinhTamGiac.Controls.Add(this.txtNhapCanhA);
            this.groupHinhTamGiac.Controls.Add(this.label7);
            this.groupHinhTamGiac.Location = new System.Drawing.Point(248, 400);
            this.groupHinhTamGiac.Name = "groupHinhTamGiac";
            this.groupHinhTamGiac.Size = new System.Drawing.Size(372, 173);
            this.groupHinhTamGiac.TabIndex = 7;
            this.groupHinhTamGiac.TabStop = false;
            this.groupHinhTamGiac.Text = "Hình tam giác";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 23);
            this.label7.TabIndex = 0;
            this.label7.Text = "Nhập cạnh a:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 95);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 23);
            this.label8.TabIndex = 1;
            this.label8.Text = "Nhập cạnh b:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 136);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 23);
            this.label9.TabIndex = 2;
            this.label9.Text = "Nhập cạnh c:";
            // 
            // txtNhapCanhC
            // 
            this.txtNhapCanhC.Location = new System.Drawing.Point(131, 126);
            this.txtNhapCanhC.Name = "txtNhapCanhC";
            this.txtNhapCanhC.Size = new System.Drawing.Size(50, 30);
            this.txtNhapCanhC.TabIndex = 3;
            // 
            // txtNhapCanhB
            // 
            this.txtNhapCanhB.Location = new System.Drawing.Point(132, 85);
            this.txtNhapCanhB.Name = "txtNhapCanhB";
            this.txtNhapCanhB.Size = new System.Drawing.Size(49, 30);
            this.txtNhapCanhB.TabIndex = 4;
            // 
            // txtNhapCanhA
            // 
            this.txtNhapCanhA.Location = new System.Drawing.Point(132, 41);
            this.txtNhapCanhA.Name = "txtNhapCanhA";
            this.txtNhapCanhA.Size = new System.Drawing.Size(49, 30);
            this.txtNhapCanhA.TabIndex = 5;
            // 
            // txtCVHinhTamGiac
            // 
            this.txtCVHinhTamGiac.Location = new System.Drawing.Point(311, 92);
            this.txtCVHinhTamGiac.Margin = new System.Windows.Forms.Padding(4);
            this.txtCVHinhTamGiac.Name = "txtCVHinhTamGiac";
            this.txtCVHinhTamGiac.Size = new System.Drawing.Size(52, 30);
            this.txtCVHinhTamGiac.TabIndex = 11;
            this.txtCVHinhTamGiac.TextChanged += new System.EventHandler(this.txtCVHinhTamGiac_TextChanged);
            // 
            // txtDTHinhTamGiac
            // 
            this.txtDTHinhTamGiac.Location = new System.Drawing.Point(311, 130);
            this.txtDTHinhTamGiac.Margin = new System.Windows.Forms.Padding(4);
            this.txtDTHinhTamGiac.Name = "txtDTHinhTamGiac";
            this.txtDTHinhTamGiac.Size = new System.Drawing.Size(50, 30);
            this.txtDTHinhTamGiac.TabIndex = 12;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(207, 95);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 23);
            this.label10.TabIndex = 10;
            this.label10.Text = "Chu vi:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(207, 136);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(98, 23);
            this.label11.TabIndex = 9;
            this.label11.Text = "Diện tích: ";
            // 
            // groupHinhChuNhat
            // 
            this.groupHinhChuNhat.Controls.Add(this.txtNhapChieuDai);
            this.groupHinhChuNhat.Controls.Add(this.txtNhapChieuRong);
            this.groupHinhChuNhat.Controls.Add(this.txtCVHinhChuNhat);
            this.groupHinhChuNhat.Controls.Add(this.label15);
            this.groupHinhChuNhat.Controls.Add(this.txtDTHinhChuNhat);
            this.groupHinhChuNhat.Controls.Add(this.label12);
            this.groupHinhChuNhat.Controls.Add(this.label13);
            this.groupHinhChuNhat.Controls.Add(this.label14);
            this.groupHinhChuNhat.Location = new System.Drawing.Point(647, 400);
            this.groupHinhChuNhat.Name = "groupHinhChuNhat";
            this.groupHinhChuNhat.Size = new System.Drawing.Size(217, 194);
            this.groupHinhChuNhat.TabIndex = 8;
            this.groupHinhChuNhat.TabStop = false;
            this.groupHinhChuNhat.Text = "Hình chữ nhật";
            // 
            // txtNhapChieuRong
            // 
            this.txtNhapChieuRong.Location = new System.Drawing.Point(155, 82);
            this.txtNhapChieuRong.Margin = new System.Windows.Forms.Padding(4);
            this.txtNhapChieuRong.Name = "txtNhapChieuRong";
            this.txtNhapChieuRong.Size = new System.Drawing.Size(52, 30);
            this.txtNhapChieuRong.TabIndex = 15;
            // 
            // txtCVHinhChuNhat
            // 
            this.txtCVHinhChuNhat.Location = new System.Drawing.Point(155, 120);
            this.txtCVHinhChuNhat.Margin = new System.Windows.Forms.Padding(4);
            this.txtCVHinhChuNhat.Name = "txtCVHinhChuNhat";
            this.txtCVHinhChuNhat.Size = new System.Drawing.Size(52, 30);
            this.txtCVHinhChuNhat.TabIndex = 13;
            // 
            // txtDTHinhChuNhat
            // 
            this.txtDTHinhChuNhat.Location = new System.Drawing.Point(155, 155);
            this.txtDTHinhChuNhat.Margin = new System.Windows.Forms.Padding(4);
            this.txtDTHinhChuNhat.Name = "txtDTHinhChuNhat";
            this.txtDTHinhChuNhat.Size = new System.Drawing.Size(50, 30);
            this.txtDTHinhChuNhat.TabIndex = 14;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 85);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(153, 23);
            this.label12.TabIndex = 12;
            this.label12.Text = "Nhập chiều rộng:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(7, 120);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 23);
            this.label13.TabIndex = 11;
            this.label13.Text = "Chu vi:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(7, 155);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(98, 23);
            this.label14.TabIndex = 10;
            this.label14.Text = "Diện tích: ";
            // 
            // txtNhapChieuDai
            // 
            this.txtNhapChieuDai.Location = new System.Drawing.Point(155, 38);
            this.txtNhapChieuDai.Margin = new System.Windows.Forms.Padding(4);
            this.txtNhapChieuDai.Name = "txtNhapChieuDai";
            this.txtNhapChieuDai.Size = new System.Drawing.Size(52, 30);
            this.txtNhapChieuDai.TabIndex = 17;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 45);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(140, 23);
            this.label15.TabIndex = 16;
            this.label15.Text = "Nhập chiều dài:";
            // 
            // groupHinhTron
            // 
            this.groupHinhTron.Controls.Add(this.txtNhapBanKinh);
            this.groupHinhTron.Controls.Add(this.txtCVHinhTron);
            this.groupHinhTron.Controls.Add(this.txtDTHinhTron);
            this.groupHinhTron.Controls.Add(this.label16);
            this.groupHinhTron.Controls.Add(this.label17);
            this.groupHinhTron.Controls.Add(this.label18);
            this.groupHinhTron.Location = new System.Drawing.Point(896, 400);
            this.groupHinhTron.Name = "groupHinhTron";
            this.groupHinhTron.Size = new System.Drawing.Size(219, 173);
            this.groupHinhTron.TabIndex = 9;
            this.groupHinhTron.TabStop = false;
            this.groupHinhTron.Text = "Hình tròn";
            // 
            // txtNhapBanKinh
            // 
            this.txtNhapBanKinh.Location = new System.Drawing.Point(160, 36);
            this.txtNhapBanKinh.Margin = new System.Windows.Forms.Padding(4);
            this.txtNhapBanKinh.Name = "txtNhapBanKinh";
            this.txtNhapBanKinh.Size = new System.Drawing.Size(52, 30);
            this.txtNhapBanKinh.TabIndex = 15;
            // 
            // txtCVHinhTron
            // 
            this.txtCVHinhTron.Location = new System.Drawing.Point(160, 80);
            this.txtCVHinhTron.Margin = new System.Windows.Forms.Padding(4);
            this.txtCVHinhTron.Name = "txtCVHinhTron";
            this.txtCVHinhTron.Size = new System.Drawing.Size(52, 30);
            this.txtCVHinhTron.TabIndex = 13;
            // 
            // txtDTHinhTron
            // 
            this.txtDTHinhTron.Location = new System.Drawing.Point(160, 118);
            this.txtDTHinhTron.Margin = new System.Windows.Forms.Padding(4);
            this.txtDTHinhTron.Name = "txtDTHinhTron";
            this.txtDTHinhTron.Size = new System.Drawing.Size(50, 30);
            this.txtDTHinhTron.TabIndex = 14;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(19, 43);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(138, 23);
            this.label16.TabIndex = 12;
            this.label16.Text = "Nhập bán kính:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(19, 87);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 23);
            this.label17.TabIndex = 11;
            this.label17.Text = "Chu vi:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(19, 128);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(98, 23);
            this.label18.TabIndex = 10;
            this.label18.Text = "Diện tích: ";
            // 
            // lblLoaiTamGiac
            // 
            this.lblLoaiTamGiac.AutoSize = true;
            this.lblLoaiTamGiac.Location = new System.Drawing.Point(208, 48);
            this.lblLoaiTamGiac.Name = "lblLoaiTamGiac";
            this.lblLoaiTamGiac.Size = new System.Drawing.Size(15, 23);
            this.lblLoaiTamGiac.TabIndex = 13;
            this.lblLoaiTamGiac.Text = " ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1200, 647);
            this.Controls.Add(this.groupHinhTron);
            this.Controls.Add(this.groupHinhChuNhat);
            this.Controls.Add(this.groupHinhTamGiac);
            this.Controls.Add(this.btnThucHien);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.groupHinhVuong);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupHinhVuong.ResumeLayout(false);
            this.groupHinhVuong.PerformLayout();
            this.groupHinhTamGiac.ResumeLayout(false);
            this.groupHinhTamGiac.PerformLayout();
            this.groupHinhChuNhat.ResumeLayout(false);
            this.groupHinhChuNhat.PerformLayout();
            this.groupHinhTron.ResumeLayout(false);
            this.groupHinhTron.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdoChuNhat;
        private System.Windows.Forms.RadioButton rdoTamGiac;
        private System.Windows.Forms.RadioButton rdoVuong;
        private System.Windows.Forms.GroupBox groupHinhVuong;
        private System.Windows.Forms.TextBox txtNhapCanhVuong;
        private System.Windows.Forms.TextBox txtDTHinhVuong;
        private System.Windows.Forms.RadioButton rdoTron;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnThucHien;
        private System.Windows.Forms.TextBox txtCVHinhVuong;
        private System.Windows.Forms.GroupBox groupHinhTamGiac;
        private System.Windows.Forms.TextBox txtCVHinhTamGiac;
        private System.Windows.Forms.TextBox txtDTHinhTamGiac;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtNhapCanhC;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtNhapCanhB;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtNhapCanhA;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupHinhChuNhat;
        private System.Windows.Forms.TextBox txtNhapChieuRong;
        private System.Windows.Forms.TextBox txtCVHinhChuNhat;
        private System.Windows.Forms.TextBox txtDTHinhChuNhat;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtNhapChieuDai;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupHinhTron;
        private System.Windows.Forms.TextBox txtNhapBanKinh;
        private System.Windows.Forms.TextBox txtCVHinhTron;
        private System.Windows.Forms.TextBox txtDTHinhTron;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblLoaiTamGiac;
    }
}

